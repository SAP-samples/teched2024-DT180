import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	def bodyAsString = message.getBody(java.lang.String);
    def xmlResponses = new XmlSlurper().parseText(bodyAsString);
    def batchWithErrors = xmlResponses?.Batch.find{it.@WorstProcessingStatus != 'PROCESSED'}?.@Id.text();
	throw new Exception("Validation errors occurred during processing at least in one IBP Batch");  	
	
	return message;
}